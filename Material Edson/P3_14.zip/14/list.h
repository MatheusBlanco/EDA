#ifndef LIST_H
#define LIST_H

#include <ostream>
#include <initializer_list>

class List {
    friend std::ostream& operator<<(std::ostream& os, const List& L)
    {
        os << "[";

        for (auto p = L.head; p != nullptr; p = p->next)
            os << " " << p->info;

        os << " ]";

        return os;
    }

public:
    List() : head(nullptr), tail(nullptr), _size(0) {}

    List(const std::initializer_list<int>& elems)
        : head(nullptr), tail(nullptr), _size(0)
    {
        for (const auto& e : elems)
            push_back(e);
    }
    
    ~List() 
    {
        auto p = head;

        while (p)
        {
            auto next = p->next;
            delete p;
            p = next;
        }

        head = tail = nullptr;
        _size = 0;
    }

    int front() const
    {
        if (head)
            return head->info;
        else
            throw "Empty list!";
    }

    int back() const
    {
        if (tail)
            return tail->info;
        else
            throw "Empty list!";
    }

    bool empty() const { return head == nullptr; }

    unsigned long size() const { return _size; }

    List& operator=(const List& L)
    {
        this->~List();

        for (auto p = L.head; p != nullptr; p = p->next)
            push_back(p->info);

        return *this;
    }
    
    bool operator==(const List& L) const
    {
        if (_size != L._size)
            return false;

        auto p = head, q = L.head;

        while (p and q)
        {
            if (p->info != q->info)
                return false;

            p = p->next;
            q = q->next;
        }

        return true;
    }

    void push_front(int info)
    {
        auto n = new Node(info, nullptr, head);

        head ? head->prev = n : tail = n;
        head = n;
        _size++;
    }

    void push_back(int info)
    {
        auto n = new Node(info, tail, nullptr);

        tail ? tail->next = n : head = n; 
        tail = n;
        _size++;
    }

    void pop_front()
    {
        if (!head)
            throw "Lista vazia";

        auto temp = head;
        head = head->next;
        delete temp;

        head ? head->prev = nullptr : tail = nullptr;
        _size--;
    }

    void pop_back()
    {
        if (!head)
            throw "Lista vazia";

        auto temp = tail;
        tail = tail->prev;
        delete temp;

        tail ? tail->next = nullptr : head = nullptr;
        _size--;
    }

    bool pop_last_but_one();

private:
    struct Node {
        int info;
        Node *prev, *next;

        Node(int i, Node *p, Node *n) : info(i), prev(p), next(n) {}
    };

    Node *head, *tail;
    unsigned long _size;
};

#endif
