#include "list.h"

bool List::pop_last_but_one()
{
    if (size() < 2)
        return false;

    auto info = back();
    pop_back();
    pop_back();
    push_back(info);

    return true;
}
