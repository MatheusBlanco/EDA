#include "list.h"

bool List::pop_last_but_one()
{
    if (size() < 2)
        return false;

    auto prev = tail->prev->prev;

    tail->prev = prev;
    prev ? prev->next = tail : head = tail;
    _size--;

    return true;
}
