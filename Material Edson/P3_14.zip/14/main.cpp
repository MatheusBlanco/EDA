#include <iostream>
#include <cassert>
#include "list.h"

using namespace std;

int main()
{
    List a;

    // Teste #01: lista vazia
    assert(a.pop_last_but_one() == false);

    // Teste #02: lista com um único elemento
    a = { 1 };
    assert(a.pop_last_but_one() == false);

    // Teste #03: lista com dois elementos
    a = { 1, 2 };
    auto ok = a.pop_last_but_one();

    assert(ok == true);
    assert(a == List({ 2 }));
    assert(a.size() == 1);

    // Teste #04: lista com 3 elementos distintos
    a = { 1, 2, 3 };

    ok = a.pop_last_but_one();

    assert(ok == true);
    assert(a == List({ 1, 3 }));
    assert(a.size() == 2);

    // Teste #05: lista com 3 elementos iguais
    a = { 1, 1, 1 };

    ok = a.pop_last_but_one();

    assert(ok == true);
    assert(a == List({ 1, 1 }));
    assert(a.size() == 2);

    // Teste #05: lista com 10 elementos 
    a = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };

    ok = a.pop_last_but_one();

    assert(ok == true);
    assert(a == List({ 1, 2, 3, 4, 5, 6, 7, 8, 10 }));
    assert(a.size() == 9);

    cout << "Ok\n";

    return 0;
}
