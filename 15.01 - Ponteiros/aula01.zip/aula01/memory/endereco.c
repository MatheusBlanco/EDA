#include <stdio.h>

int main() {
    int a = 32;
    double b = 45.0;

    printf("Enderco de a -> %p\n", &a);
    printf("Enderco de b -> %p\n", &b);

    return 0;
}
