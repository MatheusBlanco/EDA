int n_pessoas = 32;

int main() {
    static double pi = 3.1415;
    int codigo = 30;
    return 0;
}
