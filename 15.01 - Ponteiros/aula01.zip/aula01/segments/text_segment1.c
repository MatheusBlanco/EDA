int main() {
    int a = 1;

    if (a == 1) {
        a = 3;
    } else {
        a = 5;
    }

    return 0;
}
