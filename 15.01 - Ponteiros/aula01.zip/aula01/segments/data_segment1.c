int n_pessoas = 32;
int idades[] = {1, 2, 3, 4};

int main() {
    static double pi = 3.1415;
    return 0;
}
