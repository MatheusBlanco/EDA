int x_global_inicializado = 42;
double y_global_nao_inicializado;
int x_global_inicializado_com_0 = 0;

int main() {
    return 0;
}
