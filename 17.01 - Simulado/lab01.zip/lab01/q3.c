int function(int a) {
    int b = 32;
    b = a + b;

    return b;
}

int functionA(double * a) {
    int * b = (int *) malloc(3 * sizeof(int));
    static double c = 56;

    return 0;
}

int C = 45, D, E;

int main() {
    static char letra = 'A', letra1;
    int b = 3, f;

    return 0;
}
